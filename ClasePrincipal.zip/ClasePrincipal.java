import java.io.File;
import java.io.*;
import java.util.*;
import java.util.Scanner;


public class ClasePrincipal {
    public static void main(String[] args) {
        
     Proceso1 sc = new Proceso1();
     Proceso2 sou = new Proceso2();
     
     sc.start();
     sou.start();
        
    }  
    
}
